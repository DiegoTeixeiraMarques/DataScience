### Estados americanos com ggplot2

### Limpando Plots, Console and Ambiente
rm(list = ls())
dev.off(dev.list()["RStudioGD"])
cat("\014")

### Desligando notação científica
options(scipen=999)

### Carregando pacote
library(ggplot2)

### Carregando dados do pacote
data("midwest", package = "ggplot2")

### Visualização Inicial
ggplot(midwest, aes(x=area, y=poptotal))

### Gráfico de Dispersão
ggplot(midwest, aes(x=area, y=poptotal)) + geom_point()

### Regressão linear
g <- ggplot(midwest, aes(x=area, y=poptotal)) + geom_point() + geom_smooth(method="lm")
plot(g)

### Método 1 - Apagando pontos fora do escopo
g + xlim(c(0, 0.1)) + ylim(c(0, 1000000))

### Método 2 - Usando função coord_cartesian()
g <- ggplot(midwest, aes(x=area, y=poptotal)) + geom_point() + geom_smooth(method="lm")
g1 <- g + coord_cartesian(xlim=c(0,0.1), ylim=c(0, 1000000))
plot(g1)

### Mudando título e rótulo dos eixos
g1 + labs(title="Area Vs Population",
          subtitle="midwest dataset", y="Population",
          x="Area", caption="Midwest Demographics")

### Customizando o gráfico
gg <- ggplot(midwest, aes(x=area, y=poptotal)) +
  geom_point(aes(col=state), size=3) +
  geom_smooth(method="lm", col="firebrick", size=2) +
  coord_cartesian(xlim=c(0, 0.1), ylim=c(0, 1000000)) +
  labs(title="Area Vs Population", subtitle="midwest dataset",
       y="Population", x="Area", caption="Midwest Demographics")

plot(gg)

### Salvando em arquivo
ggsave("gg.pdf")
ggsave("gg.png")

